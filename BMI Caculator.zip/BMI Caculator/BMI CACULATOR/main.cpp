#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<windows.h>
#include<dos.h>
#include<dir.h>
#include<bits/stdc++.h>
using namespace std;

void SetColor(int ForgC)
{
    WORD wColor;
    HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO csbi;
    if(GetConsoleScreenBufferInfo(hStdOut, &csbi))
    {
        wColor = (csbi.wAttributes & 0xF0) + (ForgC & 0x0F);
        SetConsoleTextAttribute(hStdOut, wColor);
    }
    return;
}

int main(void)
{
    float height,weight,bmi;
    cout<<"Type in your height(m): ";
    cin>>height;
    cout<<"Type in your weight(kg): ";
    cin>>weight;
    bmi=weight/(height*height);
    if(bmi<=18.5)
    {
        SetColor(1);
        cout<<"You are underweight! ;(";
    }
    else if(bmi>=18.6&&bmi<=24.9)
    {
        SetColor(3);
        cout<<"You are normal! :)";
    }
    else if(bmi>=25&&bmi<=29.9)
    {
        SetColor(14);
        cout<<"You are overweight :(";
    }
    else if(bmi>=30)
    {
        SetColor(4);
        cout<<"You are obesity >((";
    }
    cout<<endl;
    SetColor(2);
    cout<<"Your BMI is "<<bmi;
    SetColor(13);
    cout<<endl<<"Programed By LML STUDIO";
    getch();
    return 0;
}
//Programed By LML STUDIO
//Page:https://lml-studio.itch.io/
//You can you my code without credit but I'll appreciate if you do
